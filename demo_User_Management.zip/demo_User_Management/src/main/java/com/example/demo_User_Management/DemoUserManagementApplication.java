package com.example.demo_User_Management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoUserManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoUserManagementApplication.class, args);
	}

}
