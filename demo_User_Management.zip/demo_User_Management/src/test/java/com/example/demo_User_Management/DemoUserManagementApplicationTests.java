package com.example.demo_User_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoUserManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
